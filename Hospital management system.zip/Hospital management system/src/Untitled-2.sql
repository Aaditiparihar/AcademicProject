create database hospital_management_system;
use hospital_management_system;

create Table login(ID varchar(20), PW varchar(20));
select*from login;

insert into login values("Aaditi Parihar","aaditi@123");
create Table patient_info(ID varchar(20),Number varchar(40),Name varchar(20),Gender varchar(20),patient_Disease varchar(20),Room_number varchar(20),Time varchar(100),Deposite varchar(20));

select * from patient_info;
create Table Room(room_no varchar(20),Availability varchar(20),Price varchar(20),room_type varchar(100));
select*from Room;

insert into Room values("100","Availabil","500","G Bed 1");
insert into Room values("101","Availabil","500","G Bed 2");
insert into Room values("102","Availabil","500","G Bed 3");
insert into Room values("103","Availabil","500","G Bed 4");
insert into Room values("200","Availabil","1500","Private Room");
insert into Room values("201","Availabil","1500","Private Room");
insert into Room values("202","Availabil","1500","Private Room");
insert into Room values("203","Availabil","1500","Private Room");
insert into Room values("300","Availabil","3500","ICU Bed 1");
insert into Room values("301","Availabil","3500","ICU Bed 2");
insert into Room values("302","Availabil","3500","ICU Bed 3");
insert into Room values("303","Availabil","3500","ICU Bed 4");
insert into Room values("304","Availabil","3500","ICU Bed 5");
insert into Room values("305","Availabil","3500","ICU Bed 6");


create Table department(deparpment varchar(100),Phone_no varchar(20));
select*from department;

insert into department values("Surgery Department","8945365387");
insert into department values("Nursing Department","8945362387");
insert into department values("Operation Theatre Complex (OT)","7945362387");
insert into department values("Paramedical Department","8988362387");
insert into department values("Cardiology Department","8945362487");
insert into department values("Radiology Department","8945562387");
insert into department values("Outpatient Department(OPD)","8945362327");
insert into department values("Specialized Department","8995362387");

create Table Doctor_Info(Name varchar(100),Age varchar(20),Phone_Number varchar(20),Speciality varchar(100),OPD_Timing varchar(20),Oulification varchar(20));

select*from Doctor_Info;
insert into Doctor_Info values("Dr.Anirudh M Mandhane","35","1234567890","General&Laparoscopic Surgery","9-to-10","(MS)");
insert into Doctor_Info values("Dr.Hrishikesh M Mandhane","31","1234567890","Obstretics and Gynaecology","9-to-10","(MD)");
insert into Doctor_Info values("Dr.Darshan B. Mantri","45","1234567890","Medicine and ICU","8-to-10","(MS)");
insert into Doctor_Info values("Dr.Sneha A. Mandhane","25","1234567890","Anaesthesiology","10-to-11","(MS)");
insert into Doctor_Info values("Dr.Vinit Kahalekar","38","1234567890","Gastroenterology","9-to-12","(MS)");
insert into Doctor_Info values("Dr.Ranjit Palkar","34","1234567890","Cardiology","12-to-1","(MS)");
insert into Doctor_Info values("Dr.Mayuri Dalvi","29","1234567890","Urology","1-to-2","(MD)");
insert into Doctor_Info values("Dr.Sanket Sarda","44","1234567890","Radiology","9-to-11","Radiology");
insert into Doctor_Info values("Dr.Mangesh Tandale","32","1234567890","Plastic surgery","9-to-10","(MS)");
insert into Doctor_Info values("Dr.Paramod P. Tupe","65","1234567890","Orthopedics","8-to-9","(MS)");
insert into Doctor_Info values("Dr.Nitin Kotecha","36","1234567890","Neuro Spine Surgery","12-to-1","(MS)");



create table Ambulance(name varchar(20),Gender varchar(20),Car_name varchar(20),Available varchar(20),Location varchar(20));
insert into Ambulance values("MR.patil","Male","ZEN","Available","Area 16");
insert into Ambulance values("Ms Shital","female","ZEN","Available","New roadmark");
insert into Ambulance values("MR.Kaushik","Male","ZEN","Available","Area 114");
insert into Ambulance values("Ms Nandini","female","ZEN","Available","near medical");
insert into Ambulance values("Ms Chandani","female","ZEN","Available","Area 17");
select*from Ambulance;